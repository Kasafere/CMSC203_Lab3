import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//GradebookTester class
class GradeBookTester
{
   private GradeBook g1;
   private GradeBook g2;

   @BeforeEach
   void setUp() throws Exception
   {
       //Two objects of GradeBook
	    g1 = new GradeBook(5);
		g2 = new GradeBook(5);
		
		g1.addScore(5.0);
		g1.addScore(7.0);
		g1.addScore(50.0);
		g1.addScore(75.0);
		
		g2.addScore(15.0);
		g2.addScore(55.0);
		g2.addScore(70.0);
		
   }

   @AfterEach
   void tearDown() throws Exception 
   {
   
       // assign to null
	   g1 = null;
       g2 = null;
   }

   @Test
   void testAddScore() 
   {
       //scores
	   assertTrue(g1.toString().equals("5.0 7.0 50.0 75.0 "));
	   assertTrue(g2.toString().equals("15.0 55.0 70.0 "));
	   
   }
   
   @Test
   void testGetScoreSize() 
   {
	   assertEquals(4, g1.getScoreSize(), 0.001);
	   assertEquals(3, g2.getScoreSize(),0.001);
   }

   @Test
   void testSum() 
   {
   		
   		assertEquals(137.0, g1.sum(), 0.0001);
   		assertEquals(140.0, g2.sum(), 0.0001);
   }

   @Test
   void testMinimum() 
   {
   		//minimum of numbers
   		assertEquals(5.0, g1.minimum(), 0.0001);
   		assertEquals(15.0, g2.minimum(), 0.0001);
   }
   
   @Test
	void testFinalScore() 
   {
		assertEquals(132.0, g1.finalScore(), 0.0001);
		assertEquals(125.0, g2.finalScore(), 0.0001);
   }
   
   @Test
	void testToString() 
   {
		
		//fail("Not yet implemented");
	
   }

}